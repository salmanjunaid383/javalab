package lab12;

import java.io.IOException;

public class ExceptionHandling {
	  public static void main(String args[]) {
		  try {
			  ExceptionHandling.mymethod(1);
		  }
		  
		  catch(Exception e){
			  System.out.println(e                                                                                                                                            );
		  }
		  
		  finally {
			  System.out.println("This is finally block, it will run no matter exception occurred or not");
			  
		  }
	  }
	  
	  public static void mymethod(int num) throws IOException, ClassNotFoundException{
		  if(num==1) {
			  throw new IOException("IOException occurred");
		  }
		  
		  else {
			  throw new ClassNotFoundException("ClassNotFoundException occurred");
		  }
	  }
}
